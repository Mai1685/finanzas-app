import { useState } from "react";
import { ResponsiveContainer, PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis } from "recharts";

const categorias = ["Alquiler", "Combustible", "Luz", "Gas", "Internet", "Seguro", "Monotributo"];
const colores = ["#8884d8", "#82ca9d", "#ffc658", "#ff8042", "#a4de6c", "#d0ed57", "#8dd1e1"];

export default function FinanzasApp() {
  const [ingresos, setIngresos] = useState([]);
  const [gastos, setGastos] = useState([]);
  const [inputIngreso, setInputIngreso] = useState("");
  const [inputGasto, setInputGasto] = useState({ categoria: "", monto: "" });

  const agregarIngreso = () => {
    if (!isNaN(inputIngreso) && inputIngreso !== "") {
      setIngresos([...ingresos, parseFloat(inputIngreso)]);
      setInputIngreso("");
    }
  };

  const agregarGasto = () => {
    if (!isNaN(inputGasto.monto) && inputGasto.monto !== "" && inputGasto.categoria !== "") {
      setGastos([...gastos, { categoria: inputGasto.categoria, monto: parseFloat(inputGasto.monto) }]);
      setInputGasto({ categoria: "", monto: "" });
    }
  };

  const totalIngresos = ingresos.reduce((a, b) => a + b, 0);
  const totalGastos = gastos.reduce((a, b) => a + b.monto, 0);
  const datosGastos = categorias.map((cat) => ({
    name: cat,
    value: gastos.filter((g) => g.categoria === cat).reduce((a, b) => a + b.monto, 0),
  })).filter(d => d.value > 0);

  return (
    <div style={{ padding: 20, fontFamily: "sans-serif" }}>
      <h1>Finanzas Diarias</h1>
      
      <div style={{ marginBottom: 20 }}>
        <h2>Ingresos</h2>
        <input
          type="number"
          placeholder="Monto"
          value={inputIngreso}
          onChange={(e) => setInputIngreso(e.target.value)}
        />
        <button onClick={agregarIngreso}>Agregar</button>
      </div>

      <div style={{ marginBottom: 20 }}>
        <h2>Gastos</h2>
        <select
          value={inputGasto.categoria}
          onChange={(e) => setInputGasto({ ...inputGasto, categoria: e.target.value })}
        >
          <option value="">Seleccioná categoría</option>
          {categorias.map((cat) => (
            <option key={cat} value={cat}>{cat}</option>
          ))}
        </select>
        <input
          type="number"
          placeholder="Monto"
          value={inputGasto.monto}
          onChange={(e) => setInputGasto({ ...inputGasto, monto: e.target.value })}
        />
        <button onClick={agregarGasto}>Agregar</button>
      </div>

      <div>
        <h2>Resumen</h2>
        <p>Ingresos: ${totalIngresos.toFixed(2)}</p>
        <p>Gastos: ${totalGastos.toFixed(2)}</p>
        <p>Saldo: ${(totalIngresos - totalGastos).toFixed(2)}</p>
      </div>

      <div style={{ display: 'flex', flexWrap: 'wrap', marginTop: 20 }}>
        <div style={{ width: '50%', height: 300 }}>
          <h3>Distribución de Gastos</h3>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={datosGastos} dataKey="value" nameKey="name" outerRadius={80}>
                {datosGastos.map((_, i) => (
                  <Cell key={`cell-${i}`} fill={colores[i % colores.length]} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div style={{ width: '50%', height: 300 }}>
          <h3>Ingresos vs. Gastos</h3>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={[{ name: "Hoy", Ingresos: totalIngresos, Gastos: totalGastos }]}>
              <XAxis dataKey="name" />
              <YAxis />
              <Bar dataKey="Ingresos" fill="#4ade80" />
              <Bar dataKey="Gastos" fill="#f87171" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}